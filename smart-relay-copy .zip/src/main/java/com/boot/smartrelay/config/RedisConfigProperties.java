package com.boot.smartrelay.config;

public class RedisConfigProperties {

}

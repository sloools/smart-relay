package com.boot.smartrelay;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.boot.smartrelay.*;

public class Test {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		String schedule = "08000830,09000911,09110959,09400120,11001400/0/0/0/0/0/15001700"; // 앞안겹침, 끝나는시간만겹침, 다겹침, 시작시간만겹침, 뒤안겹침
		String db = "09001000/0/0/0/0/0/0";
		
		String[] dayOfWeek = schedule.split("/");
		String[] dbDayOfWeek = db.split("/");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("HHmm");
		
		for(int i=0; i<7; i++) {
						
			if(!dayOfWeek[i].equals("0")) {
				//db 에 스케줄이 없을 때 -> input 된 애들 끼리 검증
				if(dbDayOfWeek[i].equals("0")) {
					/*
					 * input값끼리 검증 로직 
					 */
					//return true;
				//db에 스케줄이 있을 때 -> 검증
				}else {
					
					String schOfEachDay[] = dayOfWeek[i].split(",");
					String dbSchedule[] = dbDayOfWeek[i].split(",");
					
					for(String dbTime : dbSchedule) {
						Date dbStartTime, dbEndTime;
						
						dbStartTime = dateFormat.parse(dbTime.substring(0,4));
						dbEndTime = dateFormat.parse(dbTime.substring(4));
												
						for(String iTime : schOfEachDay) {	
							Date iStartTime, iEndTime;
							System.out.println("timechecking : " + iTime);
							
							iStartTime = dateFormat.parse(iTime.substring(0,4));
							iEndTime = dateFormat.parse(iTime.substring(4));
							
							System.out.println("db 시작시간 : " + dateFormat.format(dbStartTime) + ", db 마지막시간 : " + dateFormat.format(dbEndTime) +
							", input 시작시간 : " + dateFormat.format(iStartTime) + ", input 마지막시간 : " + dateFormat.format(iEndTime) 
							);
							 
//							if(iStartTime.before(dbStartTime)) {
//								System.out.println("입력시작값이 작습니다!");
//							}
							
							if(iStartTime.after(dbStartTime) && iStartTime.before(dbEndTime) && iEndTime.after(dbStartTime) && iEndTime.before(dbEndTime)) {
								System.out.println("시작 시간, 종료 시간이 모두 겹칩니다");
							}else if(iEndTime.after(dbStartTime) && iEndTime.before(dbEndTime)) {
								System.out.println("종료 시간이 겹칩니다");
							}else if(iStartTime.after(dbStartTime) && iStartTime.before(dbEndTime)) {
								System.out.println("시작 시간이 겹칩니다");
							}else {
								System.out.println("시간이 겹치지 않으므로 insert 됩니다.");
							}
							
							
//							System.out.println("db 시작시간 : " + dbStartTime + ", db 마지막시간 : " + dbEndTime +
//												", input 시작시간 : " + iStartTime + ", input 마지막시간 : " + iEndTime 
//									);
					}
					
					
						
						
						
						
//						System.out.println("start : " + startTime + " end : " + endTime);
					}
				}
				
				
				
				
				
			}
		}
		
		
	}

}

//dbStartTime = new SimpleDateFormat("HHmm");
//dbStartTime.format(dbTime.substring(0,4));
//
//dbEndTime = new SimpleDateFormat("HHmm");
//dbEndTime.format(dbTime.substring(4));

//String dbStartTime = dbTime.substring(0,4);
//String dbEndTime = dbTime.substring(4);
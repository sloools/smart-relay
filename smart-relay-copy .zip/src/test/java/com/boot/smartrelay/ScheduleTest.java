package com.boot.smartrelay;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.text.ParseException;

import org.junit.jupiter.api.Test;
import com.boot.smartrelay.service.DeviceService;

@SpringBootTest
public class ScheduleTest {
	@Autowired
	private DeviceService deviceService;
	
	@Test
	void scheduledupcheckTest() {
		try {
			deviceService.scheduledupcheck("08000830,09000911,09110959,09400120,11001400/0/0/0/0/0/15001700");
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
}
